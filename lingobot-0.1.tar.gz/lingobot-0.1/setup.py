#!/usr/bin/env python

from distutils.core import setup
setup(name='lingobot',
	version='0.1',
	author = 'John McLean',
	author_email = 'jesusfreak91@gmail.com',
	url = 'http://fedoraproject.org/wiki/User:Mcleanj/',
	packages = ['lingo'],
	package_data = {'lingo' : ['lingobot.py'] },
	scripts = ["lingobot"]
	)
