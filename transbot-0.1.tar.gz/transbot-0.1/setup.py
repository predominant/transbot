#!/usr/bin/env python

from distutils.core import setup
setup(name='transbot',
	data_files=[('/usr/share/man/man1', [ 'transbot.1' ] ) , ('/etc/', [ 'transbot.conf' ] ) ],
	version='0.1',
	author = 'John McLean',
	author_email = 'jesusfreak91@gmail.com',
	url = 'http://fedoraproject.org/wiki/User:Mcleanj/',
	packages = ['trans'],
	package_data = {'trans' : ['transbot.py'] },
	scripts = ["transbot"]
	)
